﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fanvaddetskavarajobbigt.Models
{
    public class PersonAddedEventArgs : EventArgs
    {
        public PersonAddedEventArgs(Person newPerson)
        {
            this.NewPerson = newPerson;
        }

        public Person NewPerson{ get; private set; }
    }
}
