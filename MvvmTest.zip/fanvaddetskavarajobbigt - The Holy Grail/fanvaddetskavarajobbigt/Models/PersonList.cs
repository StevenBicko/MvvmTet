﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Resources;
using System.Xml;
using System.Xml.Linq;

namespace fanvaddetskavarajobbigt.Models
{
    public class PersonList
    {
        readonly List<Person> _persons;

        public PersonList()
        {
            _persons = LoadPersons();
        }



        public event EventHandler<PersonAddedEventArgs> PersonAdded;

        public void AddPerson(Person person)
        {
            _persons.Add(person);
            if (this.PersonAdded != null)
            this.PersonAdded(this, new PersonAddedEventArgs(person));
        }

        public List<Person> GetPersons()
        {
            return new List<Person>(_persons);
        }






        public List<Person> LoadPersons()
        {
            return new List<Person>()
            {
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
                new Person() {FirstName = "Kalle", LastName = "Fuckinghelvete", Age = 23 },
            };
        }


    }
}
