﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fanvaddetskavarajobbigt.Models;

namespace fanvaddetskavarajobbigt.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        public PersonList _personList;
        public AllPersonsViewModel _allPersonsViewModel;
        public PersonViewModel _personViewModel;

        public MainViewModel()
        {
            _personList = new PersonList();
        }

        public AllPersonsViewModel AllPersonsViewModel
        {
            get
            {
                if (_allPersonsViewModel == null)
                {
                    _allPersonsViewModel = new AllPersonsViewModel(_personList);
                }
                return _allPersonsViewModel;
            }
        }

        public PersonViewModel PersonViewModel
        {
            get
            {
                _personViewModel = new PersonViewModel(null, _personList);
                return _personViewModel;
            }
        }
    }
}
