﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fanvaddetskavarajobbigt.Models;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace fanvaddetskavarajobbigt.ViewModels
{
    public class AllPersonsViewModel : BaseViewModel
    {
        readonly PersonList _personList;
        public ObservableCollection<PersonViewModel> AllPersons { get; private set; }

        public AllPersonsViewModel(PersonList personList)
        {
            _personList = personList;

            _personList.PersonAdded += this.OnPersonAddedToRepository;

            this.CreateAllPersons();
        }


        void CreateAllPersons()
        {
            List<PersonViewModel> all =
                (from pers in _personList.GetPersons()
                 select new PersonViewModel(pers, _personList)).ToList();
            this.AllPersons = new ObservableCollection<PersonViewModel>(all);
        }



        void OnPersonAddedToRepository(object sender, PersonAddedEventArgs e)
        {
            var viewModel = new PersonViewModel(e.NewPerson, _personList);
            this.AllPersons.Add(viewModel);
        }
    }
}
