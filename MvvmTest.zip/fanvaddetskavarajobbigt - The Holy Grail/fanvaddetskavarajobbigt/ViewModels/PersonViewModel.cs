﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using fanvaddetskavarajobbigt.Models;
using System.Windows.Input;

namespace fanvaddetskavarajobbigt.ViewModels
{
    public class PersonViewModel : BaseViewModel
    {
        readonly Person _person;
        readonly PersonList _personList;
        RelayCommand _saveCommand;

        public PersonViewModel(Person person, PersonList personList)
        {
            
            if (person != null) _person = person;
            else _person = new Person();           
            _personList = personList;

        }

        public string FirstName
        {
            get { return _person.FirstName; }
            set { _person.FirstName = value; }
        }

        public string LastName
        {
            get { return _person.LastName; }
            set { _person.LastName = value; }
        }

        public int Age
        {
            get { return _person.Age; }
            set { _person.Age = value; }
        }

        public ICommand SaveCommand
        {
            get {
                _saveCommand = new RelayCommand(
              param => this.Save()
              );
                return _saveCommand;
            }
        }

        public void Save()
        {
            _personList.AddPerson(_person);
        }


    }
}
